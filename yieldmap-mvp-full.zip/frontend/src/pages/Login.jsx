import React from 'react';

function Login() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Login Page</h1>
      <p>This is a placeholder login page.</p>
    </div>
  );
}

export default Login;
