# Frontend (React + Vite + Tailwind CSS)

Basic React setup using Vite and Tailwind CSS.
