# Example utility function

def greet(name):
    return f"Hello, {name}!"
