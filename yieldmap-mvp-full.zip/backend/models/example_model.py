# Example model placeholder

def get_data():
    return {'example': 'data'}
