# Backend (Flask)

Basic Flask API backend with CORS enabled.

