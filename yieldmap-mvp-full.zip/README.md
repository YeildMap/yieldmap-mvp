# yieldmap-mvp

Fullstack MVP project for YieldMap.

- React (Vite + Tailwind CSS) Frontend
- Flask Backend (API-ready)

